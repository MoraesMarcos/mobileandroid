package com.example.exercicos_04

data class Product(val name: String, val price: Double)
