package com.example.programacao // USE O SEU PACOTE AQUI

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.programacao.databinding.FragmentSegundoBinding

class SegundoFragment : Fragment(R.layout.fragment_segundo) {

    private var _binding: FragmentSegundoBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentSegundoBinding.bind(view)

        binding.button2.setOnClickListener {
            Toast.makeText(requireContext(), "Clique no Fragmento 2", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}