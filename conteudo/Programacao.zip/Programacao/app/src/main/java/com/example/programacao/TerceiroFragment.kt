package com.example.programacao // USE O SEU PACOTE AQUI

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.programacao.databinding.FragmentTerceiroBinding

class TerceiroFragment : Fragment(R.layout.fragment_terceiro) {

    private var _binding: FragmentTerceiroBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentTerceiroBinding.bind(view)

        binding.button3.setOnClickListener {
            Toast.makeText(requireContext(), "Clique no Fragmento 3", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}