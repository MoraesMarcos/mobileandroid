package com.example.programacao.model

data class Pessoa(
    val id: Long,
    val nome: String,
    val email: String
)
