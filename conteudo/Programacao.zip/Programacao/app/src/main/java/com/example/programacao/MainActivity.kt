package com.example.programacao

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import com.example.programacao.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (savedInstanceState == null) {
            abrirFragmento(PrimeiroFragment())
        }

        binding.btnNavFrag1.setOnClickListener {
            abrirFragmento(PrimeiroFragment())
        }

        binding.btnNavFrag2.setOnClickListener {
            abrirFragmento(SegundoFragment())
        }

        binding.btnNavFrag3.setOnClickListener {
            abrirFragmento(TerceiroFragment())
        }
    }

    private fun abrirFragmento(fragment: Fragment) {
        supportFragmentManager.commit {
            setReorderingAllowed(true)
            replace(R.id.fragment_container, fragment)
        }
    }
}