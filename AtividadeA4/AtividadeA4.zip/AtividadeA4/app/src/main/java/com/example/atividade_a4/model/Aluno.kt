package com.example.atividade_a4.model

data class Aluno(
    val nome: String,
    val faixa: String
)